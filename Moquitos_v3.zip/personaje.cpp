#include "personaje.h"
#include <stdlib.h>
using namespace std;

personaje::personaje(int sprClase, int cantX, int cantY, Vector2i frameActual) {
    _sprPersonaje = new sprite;
    _sprPersonaje->setSprite(sprClase, cantX, cantY, frameActual);
}

Vector2f personaje::getPosicion() {
    return _posicion;
}

void personaje::setPosicion(Vector2f position) {
    _posicion = position;
    _sprPersonaje->setPosicion(position);
}

sprite personaje::getSpritePersonaje() {
    return *_sprPersonaje;
}