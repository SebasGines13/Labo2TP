#pragma once
#include <SFML/Graphics.hpp>
#include "personaje.h"
using namespace sf;

class juego { 
private:
    Event *evento;          ///Evento es todo aquello que suceda durante el juego.
    RenderWindow *ventana;  ///Ventana donde se va a mostrar el juego.
    bool gameOver = false;  ///Booleano que controla si se termin� el juego.
    personaje *j1;          ///Objeto de clase personaje.

public:
    juego(Vector2u resolucion); //Constructor
    void inicializar(); ///Inicializa las variables y aspectos.
    void dibujar(); ///Dibuja en pantalla los elementos.
    void procesarLogica(); ///L�gicas y reglas propias del juego.
    void procesarEventos(); ///Interacci�n con el usuario, bien sea mouse, teclado, etc.
    void gameLoop();

};
