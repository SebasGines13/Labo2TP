#pragma once
#include "SFML/Graphics.hpp"
#include "sprite.h"
using namespace sf;


class personaje
{
    private:
        Vector2f _posicion; ///posici�n del jugador
        sprite *_sprPersonaje;
    public:
        personaje(int sprClase, int cantX, int cantY, Vector2i frameActual); //Constructor del personaje
        Vector2f getPosicion(); ///Devuelve la posici�n del jugador
        void setPosicion(Vector2f position); //Setea la posici�n del jugador
        sprite getSpritePersonaje();
};

