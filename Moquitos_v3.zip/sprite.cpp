#include "sprite.h"
using namespace std;


sprite::sprite() {
    
}

void sprite::setSprite(int sprClase, int cantX, int cantY, Vector2i frameActual) {
    String path = "img/personaje" + to_string(sprClase) + ".png"; //contruyo la ruta para conocer la imagen actual del sprite.
    _sprActual = sprClase; //nro del sprite actual
    _txtPersonaje = new Texture();
    _txtPersonaje->loadFromFile(path);
    _sprPersonaje = new Sprite(*_txtPersonaje);
    _cantX = cantX;
    _cantY = cantY;
    _frameSize = Vector2f(_txtPersonaje->getSize().x / _cantX, _txtPersonaje->getSize().y / _cantY);
    _frameActual = frameActual;
    seleccionarFrame();
}

void sprite::setPosicion(Vector2f position) {
    _posicion = position;
    _sprPersonaje->setPosition(position);
}

void sprite::setCantX(int cantX) {
    _cantX = cantX;
}

void sprite::setCantY(int cantY) {
    _cantY = cantY;
}

int sprite::getCantX() {
    return _cantX;
}

int sprite::getCantY() {
    return _cantY;
}

void sprite::setFrameSize(Vector2f frameSize) {
    _frameSize = frameSize;
}

Vector2f sprite::getFrameSize() {
    return _frameSize;
}

void sprite::setFrameActual(Vector2i frameActual) {
    _frameActual = frameActual;
}

Vector2i sprite::getFrameActual() {
    return _frameActual;
}

void sprite::seleccionarFrame() {
    IntRect rectangulo(_frameActual.x * _frameSize.x, _frameActual.y * _frameSize.y, _frameSize.x, _frameSize.y);
    _sprPersonaje->setTextureRect(rectangulo);
}

Sprite sprite::getSprite() {
    return *_sprPersonaje;
}