#pragma once
#include "SFML\Graphics.hpp"
using namespace sf;

class sprite{
	private:
		Texture* _txtPersonaje; ///textura del personaje
		Sprite* _sprPersonaje; ///sprite del personaje
		int _sprActual; ///Tipo de jugador (1-guerrero, 2-mago, 3-arquero)
		Vector2f _posicion; //Posicion del sprite
		int _cantX; // Cantidad de frames en el eje x
		int _cantY; // Cantidad de frames en el eje y
		Vector2f _frameSize; //Tama�o del frame.
		Vector2i _frameActual; //Frame Actual.
	public:
		//Constructor
		sprite();
		//sets
		void setSprite(int sprClase, int cantX, int cantY, Vector2i frameActual);
		void setPosicion(Vector2f position);
		void setCantX(int cantX);
		void setCantY(int cantY);
		void setFrameActual(Vector2i frameActual);
		void setFrameSize(Vector2f frameSize);
		//gets
		Sprite getSprite();		
		Vector2i getFrameActual();
		int getCantX();
		int getCantY();		
		Vector2f getFrameSize();
		//m�todos
		void seleccionarFrame();
};

