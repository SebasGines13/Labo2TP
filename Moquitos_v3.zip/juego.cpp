#include "juego.h"

juego::juego(Vector2u resolucion) { //Constructor
	ventana = new RenderWindow(VideoMode(resolucion.x, resolucion.y), "Moquitos v0.1");
	inicializar();
	gameLoop();
}


void juego::inicializar() { ///Inicializa las variables y diferentes aspectos.
	j1 = new personaje(11,4,4,Vector2i(0,0)); ///Inicilizo la variable din�minca de jugador.
	evento = new Event(); ///Inicializo la variable din�mica del evento.
}


void juego::dibujar() { ///Dibuja en pantalla los elementos.
	ventana->clear(); ///Limpio la pantalla con lo que hab�a antes.
	ventana->draw(j1->getSpritePersonaje().getSprite());
	ventana->display(); //Muestro la ventana.
} 


void juego::procesarLogica() { ///L�gicas y reglas propias del juego.

} 
void juego::procesarEventos() { ///Interacci�n con el usuario, bien sea mouse, teclado, etc.
	switch (evento->type){
		case Event::Closed: ///Para que se pueda presionar sobre la cruz y se cierre la ventana.
			exit(1);
		break;

		case Event::KeyPressed: ///Verifica si existe una tecla presionada
			if (Keyboard::isKeyPressed(Keyboard::Left)) {
				if (Keyboard::isKeyPressed(Keyboard::Up)) {
					
				}
				else if (Keyboard::isKeyPressed(Keyboard::Down)) {

				}
				else {
					j1->setPosicion(Vector2f(j1->getPosicion().x - 20, j1->getPosicion().y));
				}
			}
			else if (Keyboard::isKeyPressed(Keyboard::Right)) {
				if (Keyboard::isKeyPressed(Keyboard::Up)) {

				}
				else if (Keyboard::isKeyPressed(Keyboard::Down)) {

				}
				else {
					j1->setPosicion(Vector2f(j1->getPosicion().x + 20, j1->getPosicion().y));
				}
			}
			else if (Keyboard::isKeyPressed(Keyboard::Up)) {
				if (Keyboard::isKeyPressed(Keyboard::Left)) {

				}
				else if (Keyboard::isKeyPressed(Keyboard::Right)) {

				}
				else {
					j1->setPosicion(Vector2f(j1->getPosicion().x, j1->getPosicion().y - 20));
				}
			}
			else if (Keyboard::isKeyPressed(Keyboard::Down)) {
				j1->setPosicion(Vector2f(j1->getPosicion().x, j1->getPosicion().y + 20));
				/*
				if (Keyboard::isKeyPressed(Keyboard::Left)) {

				}
				else if (Keyboard::isKeyPressed(Keyboard::Right)) {

				}
				else {
					//j1->getSprite().setPosition(Vector2f(j1->getSprite().getPosition().x, j1->getSprite().getPosition().y + 20));
					//j1->setPosicion(Vector2f(j1->getPosicion().x, j1->getPosicion().y + 20));
				}
				*/
			}
		break;
	}
} 

void juego::gameLoop() {
	while (!gameOver) {
		while (ventana->pollEvent(*evento)) {
			procesarEventos();
		}		
		dibujar();
	}
}