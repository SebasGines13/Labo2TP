#include "juego.h"
#include <iostream>
using namespace std;


int main()
{
    juego *game = new juego(Vector2u(800, 600));
    return 0;
}
